# Git Better

This repository will have some even _interestinger_ content!

FLAG REDACTED
